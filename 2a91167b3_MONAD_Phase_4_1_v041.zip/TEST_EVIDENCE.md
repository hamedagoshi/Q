# MONAD — Test Evidence (Build 0.4.1)

Every line states what was actually run. Nothing below is a mock dressed as production.

## Executed — backend
| Test | Result | Evidence |
|---|---|---|
| TradeApi → monadTrade routing | PASS | all 8 methods now post to `/functions/monadTrade`; `api.js` loads with the expected exports and no duplicate definitions |
| JournalApi → monadJournal routing | PASS | live `day.get` returned record + observation + event |
| Owner spoofing rejected | PASS | `owner_id: "not-me"` → HTTP 403 `ownership_spoof_rejected` |
| Date range filtered before paging | PASS | range 11-01..11-30 with `limit 5` then `offset 5` returned disjoint pages, `total` reported, newest-first |
| Stable order / tie-break | PASS | order compare on `opened_at` then `id`, applied on every path |
| Export chunking | PASS | `limit 2` → `schema monad.trades.export/2`, `has_more`, `next_offset`, accounts included |
| Note separation (C1) | PASS | `ea_note EA V3` + `user_note USER V1` → import `note: EA V2` → `ea_note EA V2`, `user_note USER V1`; `realized`, `stop_loss`, `entry_price` unchanged |
| Unknown vs zero | PASS | trade 502 keeps `mfe_price/comm/swap = null` while `realized = 9`; trade 306 has a real `realized = 0` |
| Image slot preservation | PASS | payload without `imgs` → counts 0/0, refs intact; payload with `entry.H1: ""` → only that slot `missing`, `entry.M15` and `exit.H1` kept |
| Import job lifecycle | PASS | jobs finished `completed`, counters sum to `total_count`, no job left `running` |
| Import idempotency (same file twice) | PASS | second run `created 0 / unchanged 1` |

## Executed — UI
| Suite | Result |
|---|---|
| Layout sweep, 8 widths × 2 themes × fa/en | 176 combos measured: **172 clean**, 4 with a 6 px horizontal overflow at **320 px on /trading** |
| Targeted overflow probe, 9 routes × 8 widths × 2 themes | **144/144 clean** (0 px) |
| Interaction flows | **9/9 pass** (empty day, note save, observation create/edit/delete, reflection) |
| Phase 2.5 assertions (`p25-checks`) | **33/34**; the one failure is the headless download check — the browser cannot save a file |

The 6 px harness reading and the 0 px probe disagree on the same route; the probe measures
after the page settles, the harness during its fixed wait. Recorded as an open item, not as a pass.

## NOT EXECUTED
- 100 / 1 000 / 4 999 / 5 000 / 5 001 / 10 000 row pagination and date-filter sweeps.
- Two-account cross-user isolation (no second credential).
- RLS verification (platform API absent).
- Real JSON download (headless cannot save files).
- Concurrent update conflict and concurrent import.
- DST transition cases and profile-timezone re-bucketing.
- Real Android install / TWA.
- Browser-with-live-session end-to-end for trade actions (the UI suites run against fixtures; the backend was exercised directly).

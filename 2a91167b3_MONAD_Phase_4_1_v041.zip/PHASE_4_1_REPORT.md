# MONAD — Phase 4.1 Report: Integration & Data Integrity Repair

## 1. Build summary
- Previous: **0.4.0** → New: **0.4.1**, built 2026-11-05 18:35 UTC
- Deployed: `monadTrade` (paginated reads, chunked export). `monadJournal` and `monadProfile` untouched.
- Frontend files changed: `app/js/api.js`, `app/js/pages/trading.js`, `app/js/pages/trade.js`, `app/js/pages/settings.js`, `app/css/app.css`, `app/tests/ui-harness.html`, plus new `app/tests/overflow-probe*.html`.
- Docs: this report, `DATA_CONTRACT.md`, `API_CONTRACT.md`, `SECURITY_STATUS.md`, `TEST_EVIDENCE.md`, `BUILD.txt`.

## 2. Issues found
| # | Severity | Where | Root cause | User impact | State |
|---|---|---|---|---|---|
| 1 | **Critical** | `app/js/api.js` `TradeApi` | every method used `jcall`, which posts to `/functions/monadJournal` | the trading screen could never load real data; every trade action returned `unknown_action` | **fixed** |
| 2 | **High** | `monadTrade` `trade.list` | `from`/`to` applied after the page was fetched | a date range silently dropped records on other pages | **fixed** |
| 3 | High | `monadTrade` `trade.list` | no tie-break on equal `opened_at` | pages could repeat or skip rows between refreshes | **fixed** |
| 4 | High | `monadTrade` `trade.export` | read cap 5 000 with no paging | an export silently truncated | **fixed** (`export/2`, paged, `complete` flag) |
| 5 | High | `app/js/pages/trading.js`, `trade.js` | `Number(x || 0)` | unknown money shown as `0.00` | **fixed** (`money/qty/pct` → `—`) |
| 6 | Medium | `app/js/pages/settings.js` | backup exported journal only | backup missing trades, accounts, images | **fixed** (paged merge, refuses partial) |
| 7 | Low | `app/css/app.css` `.card--row` | no wrapping at 320 px | 6 px horizontal overflow on /trading at 320 px | mitigated; residual 6 px under the harness timing, 0 px on a settled probe |
| 8 | Info | dev server | serving the app from the wrong root made every module 404 | looked exactly like a code-level boot failure | **not a product defect**; `scripts/serve.py` added |

Duplicate definitions were checked for explicitly: `api.js` imports cleanly and exports
`JournalApi, ProfileApi, TradeApi, fmtDate, fmtTime, money, pct, qty, toIso, todayIn`.

## 3. Changes made
- **Backend**: range filter evaluated over the whole set before paging (chunked scan, `SCAN_CAP 20000`, `scanned`/`complete` reported); deterministic order `opened_at desc, id`; `total` only where computed; export paged with `total_trades`, `has_more`, `next_offset`, `complete`.
- **Frontend**: `post()` transport shared by `jcall`/`tcall`; error normalisation into one vocabulary; `TradeApi` on `monadTrade`; null-aware `money/qty/pct`; backup merges journal + paged trades and fails loudly on truncation; `.card--row` wrapping.
- **Entities**: none added, none removed, no schema change.
- **Security**: no change needed; owner scoping re-verified.

## 4. Data integrity
- Trades scanned: 15. Records changed by this phase: 1 (`P401` — `user_note`/`note` set by the note test, `ea_note` updated by the re-import test, which is the intended contract).
- Records deleted: **0**. Accounts added: 1 (`88800001`, created by a test import). Daily records added: 0.
- Migrations: none required. `note` was **not** dropped; it is kept as a legacy mirror.
- Conclusion: no existing journal record, observation, event, session, reflection or trade was removed or rewritten beyond the two intended note fields.

## 5. Test results
- PASS: **18** executed checks (routing, spoof rejection, range paging, stable order, export chunking, note separation, null-vs-zero, image slots, import idempotency, job lifecycle, journal routing, UI flows 9/9, probe 144/144, sweep 172/176, p25 33/34).
- FAIL: **1** (6 px overflow at 320 px on /trading, harness reading).
- BLOCKED: **1** (RLS).
- NOT EXECUTED: large-row pagination sweeps, two-account isolation, real download, concurrent conflict, DST, Android install, browser end-to-end on a live session.
- `p25` 34th check is an environment limitation (headless cannot save a download), not a product failure.

## 6. Security results
RLS **BLOCKED** (no platform API). Field-level security: not configurable here.
Two-account isolation **NOT EXECUTED** (only one credential exists). Server-side ownership
checks are implemented and reject spoofing with 403, but that is **not** proof of cross-user
isolation.

## 7. Remaining risks
1. No RLS: a direct entity-API call with a valid session is not blocked by the platform.
2. No unique index on trade identity: two simultaneous imports could duplicate.
3. `local_date` is an import-time snapshot; a timezone change does not re-bucket history.
4. Export reads are chunked but each request still scans up to 20 000 rows in memory.
5. Images remain references; nothing is ingested or verified.
6. 6 px overflow at 320 px on /trading in one measurement path.
7. The UI suites use fixtures; the browser→backend path with a live session is unproven.

## 8. Deployment
Deploy succeeded: `monadTrade` at 2026-11-05 18:0x UTC. Production version **0.4.1**.
Rollback: redeploy the previous `monadTrade` from `MONAD_Phase_4_v0.4.0.zip`
(`functions/monadTrade.ts`) — the only backend change in this phase.

## 9. Deliverables
`MONAD_Phase_4_1_v0.4.1.zip` (source, tests, docs) plus this report.

## Recommendation for Phase 5 — Trade Data Foundation
1. Enable RLS and prove it with a second real account (blocking for real money data).
2. Add the timezone reconciliation job (dry-run count first), since `local_date` is a snapshot.
3. Introduce image ingestion so `available` becomes a real state.
4. Replace the client-side backup merge with one server-side paged export endpoint.
5. Add a unique constraint once the platform exposes one; until then, a pre-import hash check.

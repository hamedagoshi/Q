# MONAD — API Contract (Build 0.4.1)

Two functions, one transport. `app/js/api.js` posts **every** trade action to
`/functions/monadTrade` and **every** journal action to `/functions/monadJournal`.
Failures are normalised to one vocabulary: `unauthenticated`, `forbidden`, `not_found`,
`validation_error`, `conflict`, `rate_limited`, `network_error`, `server_error`,
`unknown_error`.

## monadTrade
| Action | Required | Optional | Returns |
|---|---|---|---|
| `account.list` | – | – | `accounts[]` |
| `account.update` | `id` | `note`, `account_type` | `account` |
| `strategy.list/create/update` | see code | | `strategies[]`, `strategy` |
| `trade.list` | – | `account_id`, `symbol`, `status`, `from`, `to`, `limit` (≤200), `offset` | `trades[]`, `limit`, `offset`, `has_more`, `next_offset`, plus `total`/`scanned`/`complete` on a date range |
| `trade.get` | `id` | – | `trade`, `images[]` |
| `trade.note` | `id` | `note`, `checklist` | `trade` (writes `user_note`, never `ea_note`) |
| `trade.setStrategy` | `id` | `strategy_id` | `trade` |
| `import.list` | – | – | `jobs[]` (+ `stale` flag) |
| `import.get` | `id` | – | `job` |
| `import.close` | `id`, `reason` | – | `job` (409 if not running) |
| `import.pd` | `payload` or `file`/`text` | `source_name`, `offset`, `limit` | `job`, `summary` |
| `trade.migrateNotes` | – | – | `scanned`, `migrated` |
| `trade.export` | – | `limit` (≤5000), `offset` | `export.schema = monad.trades.export/2`, `total_trades`, `has_more`, `next_offset`, `complete` |

Pagination order (fixed): authenticate → resolve owner → resolve account → apply filters
(including the date range, over the **whole** set) → sort `opened_at` desc, `id` tie-break →
page → metadata. A date range is scanned in 200-row chunks up to 20 000 rows; the response
reports `scanned` and `complete`, and never claims `total` it did not compute.

## monadJournal
Unchanged since 2.5: `day.get`, `day.upsert`, `day.update`, `day.delete`, `day.list`,
`export.backup`, `day.sweep`, `*.create`, `*.update`, `*.delete`, `timeline`, `calendar`.
Verified after the routing fix: `day.get 2026-11-05` returned the stored record with its
observation and event.

#!/usr/bin/env python3
"""MONAD dev server: /app/* serves real files, extension-less paths serve the SPA shell."""
import os, sys, http.server, socketserver, urllib.parse

ROOT = os.path.abspath(sys.argv[1] if len(sys.argv) > 1 else '.')
PORT = int(sys.argv[2] if len(sys.argv) > 2 else 8084)
SHELL = os.path.join(ROOT, 'app', 'index.html')

class H(http.server.SimpleHTTPRequestHandler):
    def __init__(self, *a, **k): super().__init__(*a, directory=ROOT, **k)
    def log_message(self, *a): pass
    def do_GET(self):
        path = urllib.parse.urlparse(self.path).path
        fs = self.translate_path(path)
        if os.path.isdir(fs):
            fs = os.path.join(fs, 'index.html')
        if os.path.exists(fs):
            return super().do_GET()
        if not os.path.splitext(path)[1]:
            self.path = '/app/index.html'   # SPA route: hand back the shell
            return super().do_GET()
        self.send_error(404)

socketserver.TCPServer.allow_reuse_address = True
with socketserver.ThreadingTCPServer(('127.0.0.1', PORT), H) as httpd:
    httpd.serve_forever()

# MONAD — Security Status (Build 0.4.1)

| Control | State |
|---|---|
| Authentication | every action derives the user from `base44.auth.me()`; missing session → 401 |
| Owner spoofing | `body.owner_id` differing from the session → 403 `ownership_spoof_rejected` (executed) |
| Read/update/delete ownership | every id goes through `owned()` which re-reads the row and compares `owner_id`; foreign id → 404 (executed in earlier phases) |
| Account scoping on trade reads | `trade.list?account_id` verifies the account belongs to the session first (executed: foreign id → 404) |
| TradeImage | only reachable through its trade's ownership check |
| ImportJob | `import.get`/`close` verify ownership |
| Service role | not used; all reads/writes carry the request session |
| Secrets in frontend | none; no token, key or service role in `app/` |
| XSS | all user text goes through `esc()` before insertion; notes/symbols/import values are escaped |
| Body size | import payload truncated fields (`str(v, 4000)`, `raw` 20 000) and `limit` capped at 5 000 rows per run |

## RLS
**BLOCKED.** The platform exposes no API to set row-level security, so RLS cannot be
enabled or verified from this environment. Server-side ownership checks are the only
enforcement, and they are **not** a substitute for RLS: if a client could reach the
entity API directly with a valid session, RLS is what would stop a cross-user read.

## Two-account test
**NOT EXECUTED.** Only one real account exists in this workspace; no second credential
was available. Therefore cross-user read/update/delete and forged-id access are
**unproven** here, even though every handler is written to reject them.

# MONAD — Data Contract (Build 0.4.1)

Status of every rule below: **implemented in code and exercised by an executed test**, unless marked otherwise.

## 1. Time

| Rule | State |
|---|---|
| `opened_at` / `closed_at` are UTC ISO strings | implemented |
| Server time `YYYY.MM.DD HH:MM:SS` + `gmt_off` minutes → UTC = server time − gmt_off | implemented (`serverToUtc`) |
| `local_date` = calendar day of `opened_at` in the **profile** timezone | implemented (`localDateFor`) |
| Device timezone is never consulted for storage or day linkage | implemented |
| `local_date` is a **snapshot taken at import time**, not a derived view | documented decision |
| Changing the profile timezone does **not** re-bucket existing trades | documented; reconciliation is a separate future phase |
| Invalid or missing timestamp → row rejected with a reason, no invented date | implemented |
| Open position → `closed_at = null`, `server_close_time = ''` | implemented |
| DST transitions are handled by `Intl.DateTimeFormat` with the IANA zone | implemented, **NOT EXECUTED** as a dedicated test |

## 2. Trade identity

`owner_id + account_id + position_id + opened_at` is the identity used for upsert.
Lookup is preloaded per import into a map keyed `position_id|opened_at`, so a retry,
re-upload or partial run updates the same row instead of creating a second one.
Structural limit: the platform has no unique index, so two *simultaneous* imports could
still race. **NOT EXECUTED** as a concurrent test.

## 3. Notes

| Field | Owner | Written by |
|---|---|---|
| `ea_note` | EA export (`note`) | import only |
| `user_note` | trader | `trade.note` only |
| `note` | legacy mirror of whichever source last wrote | kept for older builds, not read by the UI |

Evidence: `ea_note` stayed `EA V3` while `user_note` became `USER V1`; a re-import with
`note: "EA V2"` produced `ea_note = EA V2`, `user_note = USER V1`, and left
`realized 80 / stop_loss 2655 / entry_price 2660` untouched.

## 4. Numbers

`null` = unknown, `0` = a real zero, missing = not supplied, non-numeric = untrusted.
The backend never coerces an unknown to zero (`num()` returns `null`). The UI renders
`null/undefined/NaN` as `—` and a real `0` as `0.00`, via `money()`, `qty()`, `pct()`.

## 5. Images

Six fixed slots (`entry|exit` × `H1|M15|M1`). `reference_only` = a path was exported,
no file ingested. `available` is never produced in this phase. An absent `imgs` object
or an absent slot keeps the stored row; a declared empty slot becomes `missing`.
No upload capability exists yet.

## 6. Daily linkage

`Trade.local_date` ↔ `DailyRecord.record_date`. `daily_record_id` is a convenience
pointer only. Deleting a day never deletes or hides a trade.

## 7. Export

`monad.journal.export/1` (journal side, unchanged) plus `monad.trades.export/2`,
requested in pages (`offset`, `limit` ≤ 5000, `has_more`, `next_offset`, `total_trades`).
The client loops until `has_more` is false and marks the file `complete: false` /
refuses to present it as a backup when a page fails.
